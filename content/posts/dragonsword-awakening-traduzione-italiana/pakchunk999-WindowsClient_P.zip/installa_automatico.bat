@echo off
chcp 65001 >nul
echo ============================================================
echo Installazione Traduzione Italiana DragonSword : Awakening
echo ============================================================
echo.

set "TARGET=C:\Program Files (x86)\Steam\steamapps\common\DragonSword  Awakening\DS\Content\Paks\~mods"

if not exist "%TARGET%" (
    echo Creo la cartella ~mods...
    mkdir "%TARGET%"
)

echo Copio il file della traduzione...
copy /y "%~dp0pakchunk999-WindowsClient_P.pak" "%TARGET%\" >nul

if %errorlevel% equ 0 (
    echo.
    echo ============================================================
    echo TRADUZIONE INSTALLATA CON SUCCESSO!
    echo ============================================================
) else (
    echo Errore durante la copia. Prova ad eseguire questo file come Amministratore.
)

echo.
pause
